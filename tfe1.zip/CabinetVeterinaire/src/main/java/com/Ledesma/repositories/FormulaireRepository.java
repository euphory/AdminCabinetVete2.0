package com.Ledesma.repositories;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.models.Formulaire;

public interface FormulaireRepository extends CrudRepository<Formulaire, Long> {

}
