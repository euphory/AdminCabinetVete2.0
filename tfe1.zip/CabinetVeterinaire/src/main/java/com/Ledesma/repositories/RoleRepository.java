package com.Ledesma.repositories;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.models.security.Role;

public interface RoleRepository extends CrudRepository<Role, Long>{
	Role findByname(String name);
}
