package com.Ledesma.controllers.formulaire;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Ledesma.models.Animal;
import com.Ledesma.models.Formulaire;
import com.Ledesma.models.User;
import com.Ledesma.services.AnimalService;
import com.Ledesma.services.FormulaireService;
import com.Ledesma.services.UserService;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/formulaire")
public class FormulaireController {
	@Autowired
	private FormulaireService formulaireService;
	@Autowired
	private AnimalService animalService;
	@Autowired
	private UserService userService;	
	
	@RequestMapping(value="/addFormulaireAdoption")
	public String animalDetail(@PathParam("id")long id, Model model, 
			Principal principal) {
		if(principal != null) {
			String username = principal.getName();
			User user = userService.findByUsername(username);
			model.addAttribute("user", user);
		}
		Animal animal = animalService.findOne(id);
		model.addAttribute("animal", animal);
		
		return "addFormulaireAdoption";
		
	}

	@RequestMapping(value="/addFormulaireAdoption", method= RequestMethod.POST)
	public String AddFomulaireAdoptionPost(Principal principal,
			@ModelAttribute("formulaire")Formulaire formulaire,
			@ModelAttribute("animal")Animal animal,
			HttpServletRequest request){
		
		if(formulaire.getDateFormulaire() == null) {
			Date date= new Date();
			formulaire.setDateFormulaire(date);
		}
		Formulaire formulaire1 = new Formulaire();
		formulaire.setId(formulaire1.getId());;

		User user = userService.findByUsername((principal.getName()));
		List<Formulaire> formulaires= new ArrayList<Formulaire>(); 
		formulaires.add(formulaire1);

		formulaire.setAnimal(animal);
		formulaire.setPersonne(user);
		animal.setFormulaires(formulaires);
		
		formulaireService.save(formulaire);
				
		
		return "redirect:/animalShelf";
	}
}
