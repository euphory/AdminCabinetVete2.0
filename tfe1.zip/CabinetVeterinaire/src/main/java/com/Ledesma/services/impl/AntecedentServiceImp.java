package com.Ledesma.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.models.Antecedent;
import com.Ledesma.repositories.AntecedentRepository;
import com.Ledesma.services.AntecedentService;

@Service
public class AntecedentServiceImp implements AntecedentService{
	@Autowired
	private AntecedentRepository antecedentRepository;

	public Antecedent save(Antecedent antecedent) {
		return antecedentRepository.save(antecedent);
	}
	public List<Antecedent> findAll(){
		return (List<Antecedent>) antecedentRepository.findAll();
	}
}
