package com.Ledesma.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.models.Poid;
import com.Ledesma.repositories.PoidRepository;
import com.Ledesma.services.PoidService;

@Service
public class PoidServiceImp implements PoidService{
	@Autowired
	private PoidRepository poidRepository;

	public Poid save(Poid poid) {
		return poidRepository.save(poid);
	}
	public List<Poid> findAll(){
		return (List<Poid>) poidRepository.findAll();
	}

}
