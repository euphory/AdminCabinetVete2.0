package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Poid;

public interface PoidService {
	Poid save(Poid poid);
	
	List<Poid> findAll();
}
