package com.Ledesma.Admin.controllers;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.models.security.PasswordResetToken;
import com.Ledesma.Admin.models.security.Role;
import com.Ledesma.Admin.models.security.UserRole;
import com.Ledesma.Admin.services.SecretaireMedicalService;
import com.Ledesma.Admin.services.UserSecurityService;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireService;
import com.Ledesma.Admin.utility.MailConstructor;
import com.Ledesma.Admin.utility.SecurityUtility;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;
	@Autowired
	private MailConstructor mailConstructor;
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private VeterinaireService veterinaireService;
	@Autowired
	private SecretaireMedicalService smService;
	@Autowired
	private UserSecurityService userSecurityService;

	@RequestMapping("/")
	public String index() {
		return "redirect:/home";
	}

	@RequestMapping("/home")
	public String home() {
		return "home";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/newAdmin", method = RequestMethod.GET)
	public String newAdmin(Model model) {
		SecretaireMedical sm = new SecretaireMedical();
		System.out.println(sm.getId());

		model.addAttribute(sm);

		return "newAdmin";
	}

	@RequestMapping(value = "/newUser", method = RequestMethod.POST)
	public String addNewUserPost(@ModelAttribute("user") SecretaireMedical user, HttpServletRequest request,
			@ModelAttribute("email") String userEmail, @ModelAttribute("username") String username,
			@ModelAttribute("numVet") int numVeto, Model model) throws Exception {

		model.addAttribute(username);
		model.addAttribute(userEmail);

		if (veterinaireService.findByUsername(username) != null) {
			model.addAttribute("usernameExists", true);
			return "newAdmin";
		}
		if (veterinaireService.findByEmail(userEmail) != null) {
			model.addAttribute("emailExists", true);
			return "newAdmin";
		}
		if (smService.findByUsername(username) != null) {
			model.addAttribute("usernameExists", true);
			return "newAdmin";
		}
		if (smService.findByEmail(userEmail) != null) {
			model.addAttribute("emailExists", true);
			return "newAdmin";
		}

		user.setUsername(username);
		user.setEmail(userEmail);
		String password = SecurityUtility.randomPassword();

		String encryptedPassword = SecurityUtility.passwordEncoder().encode(password);
		user.setPassword(encryptedPassword);
		String appUrl = "http://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();

		String token = UUID.randomUUID().toString();
		System.out.println(numVeto);
		System.out.println(user.getId());		

		if (numVeto == 0) {
			SecretaireMedical sm = new SecretaireMedical();
			Role role = new Role();
			System.out.println(role.getRoleId());
			role.setRoleId(2);
			role.setName("ROLE_SM");
			Set<UserRole> userRoles = new HashSet<>();
			userRoles.add(new UserRole(user, role));
			smService.createUser(user, userRoles);
			SimpleMailMessage email = mailConstructor.constructResetTokenEmailSM(appUrl, request.getLocale(), token,
					user, password);
			mailSender.send(email);
			System.out.println(sm.getId());
		} else {
			Veterinaire veto = new Veterinaire();
			veto.setAdress(user.getAdress());
			veto.setEmail(userEmail);
			veto.setLogin(username);
			veto.setNom(user.getNom());
			veto.setPrenom(user.getPrenom());
			veto.setPassword(user.getPassword());
			veto.setTelephone(user.getTelephone());
			veto.setNumVet(numVeto);
			System.out.println(veto.getId());
			System.out.println(veto.getNumVet());
			
			Role role = new Role();
			System.out.println(role.getRoleId());
			role.setRoleId(0);
			role.setName("ROLE_VETO");
			Set<UserRole> userRoles = new HashSet<>();
			userRoles.add(new UserRole(veto, role));
			veterinaireService.createUser(veto, userRoles);
			SimpleMailMessage email = mailConstructor.constructResetTokenEmailVeto(
					appUrl, request.getLocale(), token, veto, password);
			mailSender.send(email);
		}

		model.addAttribute("emailSent", "true");

		return "newAdmin";

	}

	@RequestMapping("/newUser")
	public String newUser(Locale locale, @RequestParam("token") String token, Model model) {
		PasswordResetToken passToken = userService.getPasswordResetToken(token);

		if (passToken == null) {
			String message = "Invalid Token.";
			model.addAttribute("message", message);
			return "redirect:/badRequest";
		}

		User user = passToken.getUser();
		String username = user.getUsername();

		UserDetails userDetails = userSecurityService.loadUserByUsername(username);

		Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails, userDetails.getPassword(),
				userDetails.getAuthorities());

		SecurityContextHolder.getContext().setAuthentication(authentication);

		model.addAttribute("user", user);

		model.addAttribute("classActiveEdit", true);
		return "newUser";
	}
}