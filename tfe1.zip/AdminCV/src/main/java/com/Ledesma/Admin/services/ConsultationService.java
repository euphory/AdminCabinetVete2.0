package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Consultation;

public interface ConsultationService {
	Consultation save(Consultation consultation);
	
	List<Consultation> findAll();
	
	Consultation findOne(Long id);
	
	void removeOne(Long id);

}
