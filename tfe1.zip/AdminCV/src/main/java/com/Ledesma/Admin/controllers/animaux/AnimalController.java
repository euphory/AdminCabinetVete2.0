package com.Ledesma.Admin.controllers.animaux;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.Ledesma.Admin.models.Animal;
import com.Ledesma.Admin.models.Antecedent;
import com.Ledesma.Admin.models.Espece;
import com.Ledesma.Admin.models.Poid;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.services.AnimalService;
import com.Ledesma.Admin.services.AntecedentService;
import com.Ledesma.Admin.services.EspeceService;
import com.Ledesma.Admin.services.PoidService;
import com.Ledesma.Admin.services.UserService;

@Controller
@RequestMapping("/animal")
public class AnimalController {

	@Autowired
	private AnimalService animalService;
	@Autowired
	private EspeceService especeService;
	@Autowired
	private PoidService poidService;
	@Autowired
	private UserService userService;
	@Autowired
	private AntecedentService antecedentService;

	@RequestMapping("/animal/animalList")
	public String animalListB(Model model) {
		List<Animal> animalList = animalService.findAll();
		model.addAttribute("animalList", animalList);
		return "/animal/animalList";
		
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String addAnimal(Model model) {
		Espece espece = new Espece();
		Animal animal = new Animal();
		Poid poid = new Poid();
		User user = new User();

		model.addAttribute("espece", espece);
		model.addAttribute("animal", animal);
		model.addAttribute("poid", poid);
		model.addAttribute("user", user);

		return "/animal/addAnimal";
	}

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public String addAnimalPost(@ModelAttribute("animal") Animal animal,
			@ModelAttribute("espece") Espece espece,
			@ModelAttribute("poid") Poid poid, @ModelAttribute("user") User user,
			HttpServletRequest request) {

		Date date = new Date();
		poid.setDate(date);
		animal.setEspece(espece);
		animal.setPersonne(user);

		poidService.save(poid);
		especeService.save(espece);
		userService.save(user);
		animalService.save(animal);

		List<Animal> animal1 = new ArrayList<Animal>();
		animal1.add(animal);
		user.setAnimaux(animal1);
		poid.setAnimal(animal);
		poidService.save(poid);

		MultipartFile animalImage = animal.getAnimalImage();

		try {
			byte[] bytes = animalImage.getBytes();
			String name = animal.getId() + ".png";
			BufferedOutputStream stream = new BufferedOutputStream(
					new FileOutputStream(new File("src/main/resources/static/image/animaux/animal" + name)));
			stream.write(bytes);
			stream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		return "redirect:/animal/animal/animalList";
	}

	@GetMapping("/animal/animalInfo")
	public String animalInfo(@RequestParam("id") long id, Model model) {
		Animal animal = animalService.findOne(id);

		List<Poid> poid = poidService.findAll();
		List<Poid> poid1 = new ArrayList<Poid>();
		for (Poid elem : poid) {
			if (elem.getAnimal().getId() == id) {
				poid1.add(elem);
			}
		}
		poid1.sort(Comparator.comparing(o -> o.getDate()));
		List<Antecedent> antece = antecedentService.findAll();
		List<Antecedent> antece1 = new ArrayList<Antecedent>();
		for (Antecedent elem : antece) {
			if (elem.getAnimal().getId() == id) {
				antece1.add(elem);
			}
		}
		antece1.sort(Comparator.comparing(o -> o.getAge()));

		model.addAttribute("anteceList", antece1);
		model.addAttribute("poidList", poid1);
		model.addAttribute("animal", animal);
		return "/animal/animalInfo";
	}

	@PostMapping("/animal/animalInfo")
	public String addPoid(Poid poid, Antecedent antecedent, @PathParam("id") long id, Model model) {
		if (poid.getId() == null) {
			if (poid.getDate() == null) {
				Date date = new Date();
				poid.setDate(date);
			}
			Poid poid1 = new Poid();
			poid.setId(poid1.getId());
			Animal animal = animalService.findOne(id);
			poid.setAnimal(animal);
			poidService.save(poid);

			model.addAttribute("animal", animal);
		} else {
			if (antecedent.getAge() == null) {
				Date date = new Date();
				antecedent.setAge(date);
			}
			System.out.println(id);
			Antecedent antece = new Antecedent();
			antecedent.setId(antece.getId());
			Animal animal = animalService.findOne(id);
			antecedent.setAnimal(animal);
			antecedentService.save(antecedent);

			model.addAttribute("animal", animal);
		}

		return "/animal/animalInfo";
	}
	@RequestMapping(value="/animal/remove", method=RequestMethod.POST)
	public String remove(@ModelAttribute("id")String id, Model model) {
		animalService.removeOne(Long.parseLong(id.substring(10)));
		List<Animal> animalList = animalService.findAll();
		model.addAttribute("animalList",animalList);
		return "/animal/animalList";
		
	}

}
