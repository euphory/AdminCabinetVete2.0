package com.Ledesma.Admin.services;

import java.util.List;
import java.util.Set;

import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.models.security.UserRole;

public interface VeterinaireService {
        
    Veterinaire findByUsername(String username);

    Veterinaire findByEmail(String email);
    
    Veterinaire findByNumVet(int numVet);
    
    Veterinaire createUser(Veterinaire veterinaire, Set<UserRole> userRoles) throws Exception;
    
    Veterinaire save(Veterinaire veterinaire);
    
    Veterinaire findOne(Long id);
    
    List<Veterinaire> findAll();
}
