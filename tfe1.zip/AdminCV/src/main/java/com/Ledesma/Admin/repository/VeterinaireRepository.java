package com.Ledesma.Admin.repository;

public interface VeterinaireRepository {

}
