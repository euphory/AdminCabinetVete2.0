package com.Ledesma.Admin.services.impl;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.models.security.UserRole;
import com.Ledesma.Admin.repository.RoleRepository;
import com.Ledesma.Admin.repository.VeterinaireRepository;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireService;

@Service
public class VeterinaireServiceImp implements VeterinaireService{
		
		private static final Logger LOG = LoggerFactory.getLogger(UserService.class);
	    
		@Autowired
		private VeterinaireRepository veterinaireRepository;
		
		@Autowired
		private RoleRepository roleRepository;
		
	    
	    @Override
	    public Veterinaire findByUsername(String username) {
	    	return (Veterinaire) veterinaireRepository.findByUsername(username);
	    }
	    
	    @Override
	    public Veterinaire findByEmail(String email) {
	    	return (Veterinaire) veterinaireRepository.findByEmail(email);
	    }
	    @Override
	    public Veterinaire createUser(Veterinaire veterinaire, Set<UserRole> userRoles) throws Exception{
	    	Veterinaire  localUser = (Veterinaire) veterinaireRepository.findByUsername(veterinaire.getUsername());
	    	
	    	if (localUser != null) {
	    		LOG.info("User{} already existe. Nothing Will be donne",veterinaire.getUsername());
	    	}else {
	    		for(UserRole ur : userRoles) {
		    			roleRepository.save(ur.getRole());
	    		}
	    		veterinaire.getUserRoles().addAll(userRoles);
	    		
	    		localUser = veterinaireRepository.save(veterinaire); 
	    	}
	    	return localUser;
	    }
	    @Override
	    public Veterinaire save(Veterinaire veterinaire){
	    	return veterinaireRepository.save(veterinaire);
	    }
	    @Override
	   	public Veterinaire findOne(Long id) {
	    	return veterinaireRepository.findById(id).orElse(null);
	    }
	    @Override
	    public List<Veterinaire> findAll(){
	    	return (List<Veterinaire>) veterinaireRepository.findAll();
	    }
	    @Override
	    public Veterinaire findByNumVet(int numVet) {
	    	return veterinaireRepository.findByNumVet(numVet);
	    }
}
