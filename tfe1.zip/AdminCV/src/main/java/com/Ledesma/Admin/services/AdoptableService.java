package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Adoptable;

public interface AdoptableService {
	Adoptable save(Adoptable adoptable);
	
	List<Adoptable> findAll();

}
