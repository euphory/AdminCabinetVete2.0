package com.Ledesma.Admin.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Animal;
import com.Ledesma.Admin.repository.AnimalRepository;
import com.Ledesma.Admin.services.AnimalService;

@Service
public class AnimalServiceImp implements AnimalService{

	@Autowired
	private AnimalRepository animalRepository;

	public Animal save(Animal animal) {
		return animalRepository.save(animal);
	}
	public List<Animal> findAll(){
		return (List<Animal>) animalRepository.findAll();
	}
	public Animal findOne(Long id) {
		return animalRepository.findById(id).orElse(null);
	}
	public void removeOne(Long id) {
		animalRepository.deleteById(id);
	}
	
	
}
