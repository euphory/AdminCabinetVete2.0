/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.Admin.models;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

/**
 *
 * @author PC
 */
@Entity
@JsonIdentityInfo(generator=ObjectIdGenerators.IntSequenceGenerator.class)
public class Animal implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length=70)
    private String surnom;
    @Temporal(TemporalType.DATE)
    private Date dateNaissance;


    @Transient
    private MultipartFile animalImage;
/**
-- -----------------------------------------------------------------------------
-- - Associations                                                            ---
-- -----------------------------------------------------------------------------   
 */
    @ManyToMany(mappedBy = "animaux")
    private List<Consultation> consultations;
   
    @ManyToOne
    @JoinColumn(name="espece_id")
    private Espece espece;
    
    @ManyToOne
    @JoinColumn(name="personne_id")
    private User personne;
        
    @OneToOne
    private Adoptable adoptable ;
        
    @OneToMany(mappedBy="animal", fetch=FetchType.LAZY)
    @JsonIgnore
    private List<Formulaire> formulaires; 
    
    @OneToMany(mappedBy="animal", fetch=FetchType.LAZY)
    @JsonIgnore
    private List<Prestation> prestations;
    
    @OneToMany(mappedBy="animal", fetch=FetchType.LAZY,cascade={CascadeType.REMOVE})
    @JsonIgnore
    private List<Antecedent> antecedents;
    
    @OneToMany(mappedBy="animal", fetch=FetchType.LAZY,cascade={CascadeType.REMOVE})
    @JsonIgnore
    private List<Poid> poid;
    /**
    -- -----------------------------------------------------------------------------
    -- - Constructor                                                             ---
    -- -----------------------------------------------------------------------------
    */
    public Animal() {}
	public Animal(Long id, String surnom, Date dateNaissance, MultipartFile animalImage,
			List<Consultation> consultations, Espece espece, User personne, Adoptable adoptable,
			List<Formulaire> formulaires, List<Prestation> prestations, List<Antecedent> antecedents, List<Poid> poid) {
		this.id = id;
		this.surnom = surnom;
		this.dateNaissance = dateNaissance;
		this.animalImage = animalImage;
		this.consultations = consultations;
		this.espece = espece;
		this.personne = personne;
		this.adoptable = adoptable;
		this.formulaires = formulaires;
		this.prestations = prestations;
		this.antecedents = antecedents;
		this.poid = poid;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSurnom() {
		return surnom;
	}
	public void setSurnom(String surnom) {
		this.surnom = surnom;
	}
    @DateTimeFormat(pattern="dd-mm-yyyy")
    public Date getDateNaissance() {
        return dateNaissance;
    }
    @DateTimeFormat(pattern="yyyy-mm-dd")
    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }
	public MultipartFile getAnimalImage() {
		return animalImage;
	}
	public void setAnimalImage(MultipartFile animalImage) {
		this.animalImage = animalImage;
	}
	public List<Consultation> getConsultations() {
		return consultations;
	}
	public void setConsultations(List<Consultation> consultations) {
		this.consultations = consultations;
	}
	public Espece getEspece() {
		return espece;
	}
	public void setEspece(Espece espece) {
		this.espece = espece;
	}
	public User getPersonne() {
		return personne;
	}
	public void setPersonne(User personne) {
		this.personne = personne;
	}
	public Adoptable getAdoptable() {
		return adoptable;
	}
	public void setAdoptable(Adoptable adoptable) {
		this.adoptable = adoptable;
	}
	public List<Formulaire> getFormulaires() {
		return formulaires;
	}
	public void setFormulaires(List<Formulaire> formulaires) {
		this.formulaires = formulaires;
	}
	public List<Prestation> getPrestations() {
		return prestations;
	}
	public void setPrestations(List<Prestation> prestations) {
		this.prestations = prestations;
	}
	public List<Antecedent> getAntecedents() {
		return antecedents;
	}
	public void setAntecedents(List<Antecedent> antecedents) {
		this.antecedents = antecedents;
	}
	public List<Poid> getPoid() {
		return poid;
	}
	public void setPoid(List<Poid> poid) {
		this.poid = poid;
	}
    


 

}