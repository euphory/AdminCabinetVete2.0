
package com.Ledesma.Admin.services;

import java.util.List;
import java.util.Set;

import com.Ledesma.Admin.models.Animal;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.security.PasswordResetToken;
import com.Ledesma.Admin.models.security.UserRole;

/**
 *
 * @author PC
 */
public interface UserService {
    
    PasswordResetToken getPasswordResetToken(final String token);
    
    void createPasswordResetTokenForUser(final User user, final String token);
    
    User findByUsername(String username);

    User findByEmail(String email);
    
    User createUser(User user, Set<UserRole> userRoles) throws Exception;
    
    User save(User user);
    
    User findOne(Long id);
    
    List<User> findAll();
}
