/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.Admin.models;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import com.Ledesma.Admin.models.security.UserRole;
import com.fasterxml.jackson.annotation.JsonIgnore;



/**
 *
 * @author PC
 */
@Entity
public class Veterinaire extends Employe {

	private long numVet;

	/**
	 * --
	 * -----------------------------------------------------------------------------
	 * -- - Association --- --
	 * -----------------------------------------------------------------------------
	 */

	@OneToMany(mappedBy = "veterinaire", fetch = FetchType.LAZY)
	@JsonIgnore
	private List<Commande> commandesVet;

	@OneToMany(mappedBy = "veterinaire", fetch = FetchType.LAZY)
	@JsonIgnore
	private List<Consultation> consultations;

	@OneToMany(mappedBy = "veterinaire", fetch = FetchType.LAZY)
	@JsonIgnore
	private List<Formulaire> formulaire;


	/**
	 * --
	 * -----------------------------------------------------------------------------
	 * -- - Constructor --- --
	 * -----------------------------------------------------------------------------
	 */



	public Veterinaire() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Veterinaire(long id, String username, String password, String nom, String prenom, String adresse,
			String telephone, long numVet, String email) {
		super(id, username, password, nom, prenom, adresse, telephone, email);
		this.numVet=numVet;
		// TODO Auto-generated constructor stub
	}

	public long getNumVet() {
		return numVet;
	}

	public void setNumVet(long numVet) {
		this.numVet = numVet;
	}

	public List<Commande> getCommandesVet() {
		return commandesVet;
	}

	public void setCommandesVet(List<Commande> commandesVet) {
		this.commandesVet = commandesVet;
	}

	public List<Consultation> getConsultations() {
		return consultations;
	}

	public void setConsultations(List<Consultation> consultations) {
		this.consultations = consultations;
	}

	public List<Formulaire> getFormulaire() {
		return formulaire;
	}

	public void setFormulaire(List<Formulaire> formulaire) {
		this.formulaire = formulaire;
	}




}
