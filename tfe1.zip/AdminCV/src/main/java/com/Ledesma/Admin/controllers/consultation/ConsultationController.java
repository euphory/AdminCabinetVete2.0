package com.Ledesma.Admin.controllers.consultation;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.services.ConsultationService;
import com.Ledesma.Admin.services.SecretaireMedicalService;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireService;
import com.mysql.cj.x.protobuf.MysqlxCrud.Collection;




@Controller
public class ConsultationController {
	@Autowired
	private ConsultationService consultationService;
	@Autowired
	private SecretaireMedicalService smService;
	@Autowired
	private VeterinaireService veterinaireService;
	@Autowired
	private UserService userService;

    @GetMapping("/consultation/consultationList")
    public String getConsultation(Model model){
        List<Consultation> consultationList = consultationService.findAll();
		consultationList.sort(Comparator.comparing(o -> o.getHeureDebut()));
		consultationList.sort(Comparator.comparing(o -> o.getDate()));
		Collections.reverse(consultationList);
		List<User> userList = userService.findAll();
		List<Veterinaire> veterinaireList = veterinaireService.findAll();
        
		model.addAttribute("vetoList", veterinaireList);
        model.addAttribute("userList", userList);
        model.addAttribute("consultationList", consultationList);
        return "/consultation/consultationList";
    }
    
    @PostMapping("/consultation/add")
    public String addNew(Consultation consultation,
                         @RequestParam String date,
                         @RequestParam String heureDebutTime,
                         @RequestParam String heureFinTime,Principal principal,
                         @RequestParam Long idPersonne,
                         @RequestParam Long idVeterinaire){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        try {
            consultation.setHeureDebut(sdf.parse(date.concat(" ").concat(heureDebutTime)));
            consultation.setHeureFin(sdf.parse(date.concat(" ").concat(heureFinTime)));
        } catch (ParseException e) {
            e.printStackTrace();
        }

        consultation.setPersonne(userService.findOne(idPersonne));
        consultation.setVeterinaire(veterinaireService.findOne(idVeterinaire));
        
        consultationService.save(consultation);
        return "redirect:/consultation/consultationList";
    }
    
    @RequestMapping("/consultation/findById")
    @ResponseBody
    public Consultation findById(Long id){
        return consultationService.findOne(id);
    }
    @RequestMapping(value="/consultation/update", method= {RequestMethod.PUT, RequestMethod.GET})
    public String update(Consultation consultation){
    consultationService.save(consultation);
    return "redirect:/consultation/consultation/consultationList";
    }
    
    @RequestMapping(value="/delete", method= {RequestMethod.DELETE, RequestMethod.GET})
    public String delete(Long id){
    consultationService.removeOne(id);
    return "redirect:/consultation/consultationList";
    }
}
