package com.Ledesma.Admin.controllers.consultation;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;




@Controller
@RequestMapping("/consultation")
public class ConsultationController {

	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String addConsultation(Model model) {
		
		
		
		return "/consultation/addConsultation";
		
	}
}


