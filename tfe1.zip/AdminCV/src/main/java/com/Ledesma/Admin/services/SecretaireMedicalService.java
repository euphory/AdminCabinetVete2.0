package com.Ledesma.Admin.services;

import java.util.Set;

import com.Ledesma.Admin.models.Employe;
import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.security.PasswordResetToken;
import com.Ledesma.Admin.models.security.UserRole;

public interface SecretaireMedicalService {
    PasswordResetToken getPasswordResetToken(final String token);
    
    void createPasswordResetTokenForUser(final SecretaireMedical user, final String token);
    
    SecretaireMedical findByUsername(String username);

    SecretaireMedical findByEmail(String email);
    
    SecretaireMedical createUser(SecretaireMedical user, Set<UserRole> userRoles) throws Exception;
    
    SecretaireMedical save(SecretaireMedical user);
}
