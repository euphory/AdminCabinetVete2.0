package com.Ledesma.Admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.Admin.models.Poid;

public interface PoidRepository extends CrudRepository<Poid, Long>{

}
