package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Antecedent;

public interface AntecedentService {
	
	Antecedent save(Antecedent antecedent);
	
	List<Antecedent> findAll();
	

}
