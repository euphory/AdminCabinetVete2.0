/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.Admin.models.security;

import java.util.Calendar;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;

/**
 *
 * @author PC
 */
@Entity
public class PasswordResetToken {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;

	private static final int EXPIRATION = 60 * 24;
	private String token;

	@OneToOne(targetEntity = User.class, fetch = FetchType.EAGER)
	@JoinColumn(nullable = true, name = "user_id")
	private User user;

	@OneToOne(targetEntity = Veterinaire.class, fetch = FetchType.EAGER)
	@JoinColumn(nullable = true, name = "employeVeterinaire_id")
	private Veterinaire veterinaire;

	@OneToOne(targetEntity = SecretaireMedical.class, fetch = FetchType.EAGER)
	@JoinColumn(nullable = true, name = "employeSecretaireMedical_id")
	private SecretaireMedical sm;
	
	private Date expiryDate;

	public PasswordResetToken() {
	}

	public PasswordResetToken(final String token, final User user) {
		super();
		this.token = token;
		this.user = user;
		this.expiryDate = calculateExpiryDate(EXPIRATION);
	}

	public Date calculateExpiryDate(final int expiryTimeInMinutes) {
		final Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(new Date().getTime());
		cal.add(Calendar.MINUTE, expiryTimeInMinutes);
		return new Date(cal.getTime().getTime());
	}

	public PasswordResetToken(final String token,final SecretaireMedical sm) {
		super();
		this.token = token;
		this.sm = sm;
		this.expiryDate = calculateExpiryDate(EXPIRATION);

	}

	public PasswordResetToken(final String token,final Veterinaire veterinaire) {
		super();
		this.token = token;
		this.veterinaire = veterinaire;
		this.expiryDate = calculateExpiryDate(EXPIRATION);

	}

	public void updateToken(final String token) {
		this.token = token;
		this.expiryDate = calculateExpiryDate(EXPIRATION);

	}

	public Long getId() {
		return id;
	}

	public static int getEXPIRATION() {
		return EXPIRATION;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public Date getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(Date expiryDate) {
		this.expiryDate = expiryDate;
	}

	@Override
	public String toString() {
		return "PasswordRestToken{" + "id=" + id + ", token=" + token + ", user=" + user + ", expiryDate=" + expiryDate
				+ '}';
	}

	public Veterinaire getVeto() {
		return veterinaire;
	}

	public void setVeto(Veterinaire veto) {
		this.veterinaire = veto;
	}

	public SecretaireMedical getSm() {
		return sm;
	}

	public void setSm(SecretaireMedical sm) {
		this.sm = sm;
	}
}