package com.Ledesma.Admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.Admin.models.Employe;
import com.Ledesma.Admin.models.SecretaireMedical;

public interface SecretaireMedicalRepository extends CrudRepository<SecretaireMedical, Long>{
	SecretaireMedical findByUsername(String username);
    
	SecretaireMedical findByEmail(String useremail);
    

    
}
