package com.Ledesma.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.models.Formulaire;
import com.Ledesma.repositories.FormulaireRepository;
import com.Ledesma.services.FormulaireService;

@Service
public class FormulaireServiceImp implements FormulaireService{
	@Autowired
	private FormulaireRepository formulaireRepository;

	public Formulaire save(Formulaire formulaire) {
		return formulaireRepository.save(formulaire);
	}
	public List<Formulaire> findAll(){
		return (List<Formulaire>) formulaireRepository.findAll();
	}
	public Formulaire findOne(long id) {
		return formulaireRepository.findById(id).orElse(null);
	}
	
}
