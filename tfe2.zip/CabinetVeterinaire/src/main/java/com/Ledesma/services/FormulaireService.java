package com.Ledesma.services;

import java.util.List;

import com.Ledesma.models.Formulaire;

public interface FormulaireService {
	
	Formulaire save(Formulaire formulaire);
	
	List<Formulaire> findAll();
	
	 Formulaire findOne(long id);

}
