package com.Ledesma.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.models.Espece;
import com.Ledesma.repositories.EspeceRepository;
import com.Ledesma.services.EspeceService;

@Service
public class EspeceServiceImp implements EspeceService{
	@Autowired
	private EspeceRepository especeRepository;

	public Espece save(Espece espece) {
		return especeRepository.save(espece);
	}
	public List<Espece> findAll(){
		return (List<Espece>) especeRepository.findAll();
	}

}
