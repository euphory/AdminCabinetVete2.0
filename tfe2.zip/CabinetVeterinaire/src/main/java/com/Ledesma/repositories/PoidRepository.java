package com.Ledesma.repositories;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.models.Poid;

public interface PoidRepository extends CrudRepository<Poid, Long>{

}
