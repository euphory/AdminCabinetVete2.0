package com.Ledesma.repositories;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.models.Adoptable;

public interface AdoptableRepository extends CrudRepository<Adoptable, Long> {

}
	