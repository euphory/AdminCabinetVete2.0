/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.models.security;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.Ledesma.models.SecretaireMedical;
import com.Ledesma.models.User;
import com.Ledesma.models.Veterinaire;




@Entity
@Table(name="user_role")
public class UserRole {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long userRoleId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="user_id")
	private User user;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="role_id")
	private Role role;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="employeVeterinaire_id")
	private Veterinaire veterinaire;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="employeSecretaireMedical_id")
	private SecretaireMedical sm;
	
	public UserRole(){}
    public UserRole( User user, Role role) {
        this.user = user;
        this.role = role;
    }
    
    public UserRole(User user, Role role, Veterinaire veterinaire, SecretaireMedical sm) {
		super();
		this.user = user;
		this.role = role;
		this.veterinaire = veterinaire;
		this.sm = sm;
	}
	public UserRole(Role role, SecretaireMedical sm) {
		super();
		this.role = role;
		this.sm = sm;
	}
	public UserRole(Role role, Veterinaire veterinaire) {
		super();
		this.role = role;
		this.veterinaire = veterinaire;
	}
	public Long getUserRoleId() {
        return userRoleId;
    }

    public void setUserRoleId(Long userRoleId) {
        this.userRoleId = userRoleId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }
	public Veterinaire getVeterinaire() {
		return veterinaire;
	}
	public void setVeterinaire(Veterinaire veterinaire) {
		this.veterinaire = veterinaire;
	}
	public SecretaireMedical getSm() {
		return sm;
	}
	public void setSm(SecretaireMedical sm) {
		this.sm = sm;
	}


	
}
