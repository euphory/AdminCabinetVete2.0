/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.Admin.models;

import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.Ledesma.Admin.models.security.Authority;
import com.Ledesma.Admin.models.security.UserRole;
import com.fasterxml.jackson.annotation.JsonIgnore;

/**
 *
 * @author PC
 */
@Entity
public class SecretaireMedical extends Employe implements UserDetails{
	
	private boolean enabled=true;
    
	/**
	 * -----------------------------------------------------------------------------
	 * -- - Association --- --
	 * -----------------------------------------------------------------------------
	 */
	@OneToMany(mappedBy = "secretaireMedical", fetch = FetchType.LAZY)
	@JsonIgnore
	private List<Commande> commandes;

	@OneToMany(mappedBy = "secretaireMedical", fetch = FetchType.LAZY)
	@JsonIgnore
	private List<Consultation> consultations;
	
    @OneToMany(mappedBy = "sm", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonIgnore
    private Set<UserRole> userRoles = new HashSet<>();


	/**
	 * -----------------------------------------------------------------------------
	 * -- - Constructor --- --
	 * -----------------------------------------------------------------------------
	 */


	public SecretaireMedical() {
		super();
	}

	public SecretaireMedical(Long id, String username, String password, String nom, String prenom, String adresse,
			String telephone, String email) {
		super(id, username, password, nom, prenom, adresse, telephone, email);
	}
	public List<Commande> getCommandes() {
		return commandes;
	}
	

	public void setCommandes(List<Commande> commandes) {
		this.commandes = commandes;
	}

	public List<Consultation> getConsultations() {
		return consultations;
	}

	public void setConsultations(List<Consultation> consultations) {
		this.consultations = consultations;
	}

	public Set<UserRole> getUserRoles() {
		return userRoles;
	}

	public void setUserRoles(Set<UserRole> userRoles) {
		this.userRoles = userRoles;
	}

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        Set<GrantedAuthority> authorities = new HashSet();
        userRoles.forEach(ur -> authorities.add(new Authority(ur.getRole().getName())));
        return authorities;

    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
       return enabled;
    }



}