package com.Ledesma.Admin.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.repository.ConsultationRepository;
import com.Ledesma.Admin.services.ConsultationService;

@Service
public class ConsultationServiceImp implements ConsultationService
{
	@Autowired
	private ConsultationRepository consultationRepository;

	public Consultation save(Consultation consultation) {
		return consultationRepository.save(consultation);
	}
	public List<Consultation> findAll(){
		return (List<Consultation>) consultationRepository.findAll();
	}
	public Consultation findOne(Long id) {
		return consultationRepository.findById(id).orElse(null);
	}
	public void removeOne(Long id) {
		consultationRepository.deleteById(id);
	}
	public void removeAllById(List<Consultation> entities) {
		consultationRepository.deleteAll(entities);
	}
}
