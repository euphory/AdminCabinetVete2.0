package com.Ledesma.Admin.utility;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.stereotype.Component;

import com.Ledesma.Admin.models.Formulaire;
import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;

@Component
public class MailConstructor {
	@Autowired
	private Environment env;

	public SimpleMailMessage constructResetTokenEmail(String contextPath, Locale locale, String token, User user,
			String password) {

		String url = contextPath + "/newUser?token=" + token;
		String message = "\nPlease click on this link to verify your email and edit your personal information."
				+ "\n Your password is: \n" + password;
		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(user.getEmail());
		email.setSubject("CabinetVeterinaire - New User");
		email.setText(url + message);
		email.setFrom(env.getProperty("support.email"));
		return email;

	}

	public SimpleMailMessage constructResetTokenEmailVeto(String contextPath, Locale locale, String token,
			Veterinaire user, String password) {

		String url = contextPath + "/login";
		String message = "\nPlease click on this link to verify your email and edit your personal information."
				+ "\n Your temporary password is: \n" + password;
		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(user.getEmail());
		email.setSubject("CabinetVeterinaire - Veterinaire");
		email.setText(url + message);
		email.setFrom(env.getProperty("support.email"));
		return email;

	}

	public SimpleMailMessage constructResetTokenEmailSM(String contextPath, Locale locale, String token,
			SecretaireMedical user, String password) {

		String url = contextPath + "/login";
		String message = "\nPlease click on this link to verify your email and edit your personal information. "
				+ "\n Your temporary password is: \n" + password;
		SimpleMailMessage email = new SimpleMailMessage();
		email.setTo(user.getEmail());
		email.setSubject("CabinetVeterinaire - New Secretaire medical");
		email.setText(url + message);
		email.setFrom(env.getProperty("support.email"));
		return email;
	}

	public SimpleMailMessage acceptationFormulaire(Locale locale, Formulaire formulaire) {
		SimpleMailMessage email = new SimpleMailMessage();
		String message = "\nFelicitation vote demande d'adoption de ce petit "
				+ formulaire.getAnimal().getEspece().getNom() + " , " + formulaire.getAnimal().getSurnom()
				+ " à été accepte. par le Vétérinaire " + formulaire.getVeterinaire().getNom() + " "
				+ formulaire.getVeterinaire().getPrenom() + "\nVous pouvez venir recuperer l'animal au "
				+ "Cabinet Veterinaire aux heures d'ouverture. les frai à payé sont de "
				+ formulaire.getAdoption().getFrais() + "€";
		email.setTo(formulaire.getPersonne().getEmail());
		email.setSubject("Cabinet Veterinaire - Resultat de la demande d'adoption");
		email.setText(message);
		email.setFrom(env.getProperty("support.email"));

		return email;
	}

	public SimpleMailMessage refusFormulaire(Locale locale, Formulaire formulaire) {
		SimpleMailMessage email = new SimpleMailMessage();
		String message = "\nDésolé vote demande d'adoption de ce petit " + formulaire.getAnimal().getEspece().getNom()
				+ " , " + formulaire.getAnimal().getSurnom() + " à été refusé.Par le Vétérianire ";
		email.setTo(formulaire.getPersonne().getEmail());
		email.setSubject("Cabinet Veterinaire - Resultat de la demande d'adoption");
		email.setText(message);
		email.setFrom(env.getProperty("support.email"));

		return email;
	}
}
