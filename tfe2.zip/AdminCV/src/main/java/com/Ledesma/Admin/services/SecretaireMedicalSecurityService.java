package com.Ledesma.Admin.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.repository.SecretaireMedicalRepository;


	@Service
	public class SecretaireMedicalSecurityService implements UserDetailsService{
		
		@Autowired
		private SecretaireMedicalRepository smRepository;

		@Override
		public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
			SecretaireMedical user = smRepository.findByUsername(username);
			
			if(null == user) {
				throw new UsernameNotFoundException("Username not found");
			}
			
			return user;
		}
		

	}