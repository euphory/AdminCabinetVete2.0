package com.Ledesma.Admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.Admin.models.Formulaire;

public interface FormulaireRepository extends CrudRepository<Formulaire, Long> {

}
