package com.Ledesma.Admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.Admin.models.Employe;

public interface EmployeRepository extends CrudRepository<Employe, Long>{
    Employe findByUsername(String username);
    
    Employe findByEmail(String useremail);
}