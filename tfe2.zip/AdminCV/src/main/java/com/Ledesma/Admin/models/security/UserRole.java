/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.Admin.models.security;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;




@Entity
@Table(name="user_role")
public class UserRole {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long userRoleId;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="user_id")
	private User user;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="role_id")
	private Role role;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="employeVeterinaire_id")
	private Veterinaire veterinaire;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="employeSecretaireMedical_id")
	private SecretaireMedical sm;
	
	public UserRole(){}
    public UserRole( User user, Role role) {
        this.user = user;
        this.role = role;
    }
    public UserRole(Veterinaire veterinaire, Role role) {
    	this.veterinaire = veterinaire;
    	this.role = role;
    }
    public UserRole(SecretaireMedical sm, Role role) {
    	this.sm = sm;
    	this.role = role;
    }

    public Long getUserRoleId() {
        return userRoleId;
    }

    public void setUserRoleId(Long userRoleId) {
        this.userRoleId = userRoleId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Role getRole() {
        return role;
    }
	public Veterinaire getVeterinaire() {
		return veterinaire;
	}
	public void setVeterinaire(Veterinaire veterinaire) {
		this.veterinaire = veterinaire;
	}
	public SecretaireMedical getSm() {
		return sm;
	}
	public void setSm(SecretaireMedical sm) {
		this.sm = sm;
	}
	public void setRole(Role role) {
		this.role = role;
	}

  

	
}
