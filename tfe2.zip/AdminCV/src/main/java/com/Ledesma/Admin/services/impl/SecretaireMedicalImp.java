package com.Ledesma.Admin.services.impl;

import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.models.security.PasswordResetToken;
import com.Ledesma.Admin.models.security.UserRole;
import com.Ledesma.Admin.repository.PasswordResetTokenRepository;
import com.Ledesma.Admin.repository.RoleRepository;
import com.Ledesma.Admin.repository.SecretaireMedicalRepository;
import com.Ledesma.Admin.services.SecretaireMedicalService;
import com.Ledesma.Admin.services.UserService;

@Service
public class SecretaireMedicalImp implements SecretaireMedicalService{
	private static final Logger LOG = LoggerFactory.getLogger(UserService.class);
    
	@Autowired
	private SecretaireMedicalRepository secretaireMedicalRepository;
	
	@Autowired
	private RoleRepository roleRepository;
	
    
    @Override
    public SecretaireMedical findByUsername(String username) {
    	return  secretaireMedicalRepository.findByUsername(username);
    }
    
    @Override
    public SecretaireMedical findByEmail(String email) {
    	return secretaireMedicalRepository.findByEmail(email);
    }
    @Override
    public SecretaireMedical createUser(SecretaireMedical sm, Set<UserRole> userRoles) throws Exception{
    	SecretaireMedical  localUser = (SecretaireMedical) secretaireMedicalRepository.findByUsername(sm.getUsername());
    	
    	if (localUser != null) {
    		LOG.info("User{} already existe. Nothing Will be donne",sm.getUsername());
    	}else {
    		for(UserRole ur : userRoles) {
    			roleRepository.save(ur.getRole());
    		}
    		sm.getUserRoles().addAll(userRoles);
    		
    		localUser = secretaireMedicalRepository.save(sm); 
    	}
    	return localUser;
    }
    @Override
    public SecretaireMedical save(SecretaireMedical sm){
    	return secretaireMedicalRepository.save(sm);
    }
    @Override
    public SecretaireMedical findOne(Long id) {
    	return secretaireMedicalRepository.findById(id).orElse(null);
    }
    @Override
	public List<SecretaireMedical> findAll(){
		return (List<SecretaireMedical>) secretaireMedicalRepository.findAll();
	}
    @Override
	public void removeOne(Long id){
    	secretaireMedicalRepository.deleteById(id);
    }
}