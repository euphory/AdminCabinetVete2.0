package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Espece;


public interface EspeceService {
	Espece save(Espece espece);
	
	List<Espece> findAll();
}
