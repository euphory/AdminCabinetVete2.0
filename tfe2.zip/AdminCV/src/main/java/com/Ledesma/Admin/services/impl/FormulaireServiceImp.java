package com.Ledesma.Admin.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Formulaire;
import com.Ledesma.Admin.repository.FormulaireRepository;
import com.Ledesma.Admin.services.FormulaireService;

@Service
public class FormulaireServiceImp implements FormulaireService{

	@Autowired
	private FormulaireRepository formulaireRepository;

	public Formulaire save(Formulaire formulaire) {
		return formulaireRepository.save(formulaire);
	}

	public List<Formulaire> findAll() {
		return (List<Formulaire>) formulaireRepository.findAll();
	}

	public Formulaire findOne(Long id) {
		return formulaireRepository.findById(id).orElse(null);
	}

	public void removeOne(Long id) {
			formulaireRepository.deleteById(id);
		}
}
