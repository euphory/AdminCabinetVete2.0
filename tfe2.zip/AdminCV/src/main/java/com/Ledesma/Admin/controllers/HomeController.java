package com.Ledesma.Admin.controllers;

import java.security.Principal;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.models.security.PasswordResetToken;
import com.Ledesma.Admin.models.security.Role;
import com.Ledesma.Admin.models.security.UserRole;
import com.Ledesma.Admin.services.SecretaireMedicalSecurityService;
import com.Ledesma.Admin.services.SecretaireMedicalService;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireSecurityService;
import com.Ledesma.Admin.services.VeterinaireService;
import com.Ledesma.Admin.utility.MailConstructor;
import com.Ledesma.Admin.utility.SecurityUtility;

@Controller
public class HomeController {

	@Autowired
	private UserService userService;
	@Autowired
	private MailConstructor mailConstructor;
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private VeterinaireService veterinaireService;
	@Autowired
	private SecretaireMedicalService smService;
	@Autowired
	private VeterinaireSecurityService vetoSecurityService;
	@Autowired
	private SecretaireMedicalSecurityService smSecurityService;

	@RequestMapping("/")
	public String index() {
		return "redirect:/home";
	}

	@RequestMapping("/home")
	public String home() {
		return "home";
	}

	@RequestMapping("/login")
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/newAdmin", method = RequestMethod.GET)
	public String newAdmin(Model model) {
		SecretaireMedical sm = new SecretaireMedical();

		model.addAttribute(sm);

		return "newAdmin";
	}

	@RequestMapping(value = "/newUser", method = RequestMethod.POST)
	public String addNewUserPost(@ModelAttribute("user") SecretaireMedical user, HttpServletRequest request,
			@ModelAttribute("email") String userEmail, @ModelAttribute("username") String username,
			@ModelAttribute("numVet") int numVeto, Model model) throws Exception {

		model.addAttribute(username);
		model.addAttribute(userEmail);

		if (veterinaireService.findByUsername(username) != null) {
			model.addAttribute("usernameExists", true);
			return "newAdmin";
		}
		if (veterinaireService.findByEmail(userEmail) != null) {
			model.addAttribute("emailExists", true);
			return "newAdmin";
		}
		if (smService.findByUsername(username) != null) {
			model.addAttribute("usernameExists", true);
			return "newAdmin";
		}
		if (smService.findByEmail(userEmail) != null) {
			model.addAttribute("emailExists", true);
			return "newAdmin";
		}

		user.setUsername(username);
		user.setEmail(userEmail);
		String password = SecurityUtility.randomPassword();

		String encryptedPassword = SecurityUtility.passwordEncoder().encode(password);
		user.setPassword(encryptedPassword);
		String appUrl = "http://" + request.getServerName() + ":" + request.getServerPort() + request.getContextPath();

		String token = UUID.randomUUID().toString();

		if (numVeto <= 0) {
			SecretaireMedical sm = new SecretaireMedical();
			Role role = new Role();
			role.setRoleId(2);
			role.setName("ROLE_SM");
			Set<UserRole> userRoles = new HashSet<>();
			userRoles.add(new UserRole(user, role));
			smService.createUser(user, userRoles);
			SimpleMailMessage email = mailConstructor.constructResetTokenEmailSM(appUrl, request.getLocale(), token,
					user, password);
			mailSender.send(email);
		} else {
			if (veterinaireService.findByNumVet(numVeto) != null) {
				model.addAttribute("numVetExists", true);
				return "newAdmin";
			}
			Veterinaire veto = new Veterinaire();
			veto.setAdresse(user.getAdresse());
			veto.setEmail(userEmail);
			veto.setLogin(username);
			veto.setNom(user.getNom());
			veto.setPrenom(user.getPrenom());
			veto.setPassword(user.getPassword());
			veto.setTelephone(user.getTelephone());
			veto.setNumVet(numVeto);

			Role role = new Role();
			role.setRoleId(3);
			role.setName("ROLE_VETO");
			Set<UserRole> userRoles = new HashSet<>();
			userRoles.add(new UserRole(veto, role));
			veterinaireService.createUser(veto, userRoles);
			SimpleMailMessage email = mailConstructor.constructResetTokenEmailVeto(appUrl, request.getLocale(), token,
					veto, password);
			mailSender.send(email);
		}

		model.addAttribute("emailSent", "true");

		return "newAdmin";

	}

	@RequestMapping("/myProfile")
	public String myProfile(Model model, Principal principal) {
		String username = principal.getName();
		if (smService.findByUsername(username) != null) {
			SecretaireMedical sm = smService.findByUsername(username);
			
			model.addAttribute("user", sm);
		}
		if (veterinaireService.findByUsername(username) != null) {
			Veterinaire veto = veterinaireService.findByUsername(username);
			model.addAttribute("numvetExist", true);
			model.addAttribute("user", veto);
			return "myProfile";
		}

		return "myProfile";

	}

	@RequestMapping(value = "/updateInfo", method = RequestMethod.POST)
	public String updateInfo(@ModelAttribute("user") SecretaireMedical user,
			@ModelAttribute("newPassword") String newPassword, 
			@ModelAttribute("currentPassword") CharSequence currentPassword,
			@ModelAttribute("numVet")int numVet ,Model model) throws Exception {
		SecretaireMedical currentSM = smService.findByUsername(user.getUsername());
		System.out.println(user.getId());
		Veterinaire currentVeto = veterinaireService.findByUsername(user.getUsername());
		if (currentSM != null ) {
			/* check email already exists */

			if (smService.findByEmail(user.getEmail()) != null) {
				if (smService.findByEmail(user.getEmail()).getId() != currentSM.getId()) {
					model.addAttribute("emailExists", true);
					return "myProfile";
				}
			}

			/* check username already exists */
			if (smService.findByUsername(user.getUsername()) != null) {
				if (smService.findByUsername(user.getUsername()).getId() != currentSM.getId()) {
					model.addAttribute("usernameExists", true);
					return "myProfile";
				}
			}

//		update password
			if (newPassword != null && !newPassword.isEmpty() && !newPassword.equals("")) {
				BCryptPasswordEncoder passwordEncoder = SecurityUtility.passwordEncoder();
				String dbPassword = currentSM.getPassword();				
				if (passwordEncoder.matches(currentPassword, dbPassword)) {
					currentSM.setPassword(passwordEncoder.encode(newPassword));
				} else {
					model.addAttribute("updateEchec", true);

					return "myProfile";
				}
			}
			currentSM.setPrenom(user.getPrenom());
			currentSM.setNom(user.getNom());
			currentSM.setUsername(user.getUsername());
			currentSM.setEmail(user.getEmail());
			currentSM.setAdresse(user.getAdresse());
			model.addAttribute("user", currentSM);
			UserDetails userDetails = smSecurityService.loadUserByUsername(currentSM.getUsername());
			Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails,
					userDetails.getPassword(), userDetails.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(authentication);
			smService.save(currentSM);
		}

		/*---- Veterinaire update */
		if (currentVeto != null) {
			/* check email already exists */
			if (veterinaireService.findByEmail(user.getEmail()) != null) {
				if (veterinaireService.findByEmail(user.getEmail()).getId() != currentVeto.getId()) {
					model.addAttribute("emailExists", true);
					return "myProfile";
				}
			}

			/* check username already exists */
			if (veterinaireService.findByUsername(user.getUsername()) != null) {
				if (veterinaireService.findByUsername(user.getUsername()).getId() != currentVeto.getId()) {
					model.addAttribute("usernameExists", true);
					return "myProfile";
				}
			}

//			update password
			if (newPassword != null && !newPassword.isEmpty() && !newPassword.equals("")) {
				BCryptPasswordEncoder passwordEncoder = SecurityUtility.passwordEncoder();
				String dbPassword = currentVeto.getPassword();				
				if (passwordEncoder.matches(currentPassword, dbPassword)) {
					currentVeto.setPassword(passwordEncoder.encode(newPassword));
				} else {
					model.addAttribute("updateEchec", true);

					return "myProfile";
				}
			}
			currentVeto.setId(user.getId());
			currentVeto.setPrenom(user.getPrenom());
			currentVeto.setNom(user.getNom());
			currentVeto.setUsername(user.getUsername());
			currentVeto.setEmail(user.getEmail());
			currentVeto.setAdresse(user.getAdresse());
			currentVeto.setTelephone(user.getTelephone());
			currentVeto.setNumVet(numVet);
			model.addAttribute("numvetExist", true);
			model.addAttribute("numVet", numVet);
			model.addAttribute("user", currentVeto);
			UserDetails userDetails = vetoSecurityService.loadUserByUsername(currentVeto.getUsername());
			Authentication authentication = new UsernamePasswordAuthenticationToken(userDetails,
					userDetails.getPassword(), userDetails.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(authentication);
			veterinaireService.save(currentVeto);
		}
		if (currentSM == null && currentVeto == null) {
			throw new Exception("User not found");
		}
		model.addAttribute("updateSuccess", true);

		return "myProfile";
	}
	


}