package com.Ledesma.Admin.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Poid;
import com.Ledesma.Admin.repository.PoidRepository;
import com.Ledesma.Admin.services.PoidService;

@Service
public class PoidServiceImp implements PoidService{
	@Autowired
	private PoidRepository poidRepository;

	public Poid save(Poid poid) {
		return poidRepository.save(poid);
	}
	public List<Poid> findAll(){
		return (List<Poid>) poidRepository.findAll();
	}

}
