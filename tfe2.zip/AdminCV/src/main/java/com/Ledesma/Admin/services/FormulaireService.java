package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Formulaire;

public interface FormulaireService {
	Formulaire save(Formulaire formulaire);
	
	List<Formulaire> findAll();
	
	Formulaire findOne(Long id);
	
	void removeOne(Long id);
}
