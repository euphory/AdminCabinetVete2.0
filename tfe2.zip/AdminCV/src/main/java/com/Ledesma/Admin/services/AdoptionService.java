package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Adoptable;
import com.Ledesma.Admin.models.Adoption;

public interface AdoptionService {
	Adoption save(Adoption adoption);

	List<Adoption> findAll();

	Adoption findOne(Long id);

	void removeOne(Long id);

}
