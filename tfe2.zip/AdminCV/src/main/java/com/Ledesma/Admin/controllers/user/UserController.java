package com.Ledesma.Admin.controllers.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.Ledesma.Admin.models.Animal;
import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.models.Formulaire;
import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.services.AnimalService;
import com.Ledesma.Admin.services.ConsultationService;
import com.Ledesma.Admin.services.FormulaireService;
import com.Ledesma.Admin.services.SecretaireMedicalService;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireService;

@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserService userService;
	@Autowired
	private VeterinaireService veterinaireService;
	@Autowired
	private SecretaireMedicalService smService;
	@Autowired
	private ConsultationService consultService;
	@Autowired
	private AnimalService animalService;
	@Autowired
	private FormulaireService formulaireService;

	@GetMapping("/listUsers")
	public String getListUsers(Model model) {
		List<User> userList = userService.findAll();
		userList.remove(0);
		model.addAttribute("userList", userList);
		return "/user/listUsers";
	}
	

	@RequestMapping(value = "/remove", method = RequestMethod.POST)
	public String remove(@ModelAttribute("id") String id, Model model) {
		User user = userService.findOne(Long.parseLong(id.substring(8)));
		List<User> userList = userService.findAll();
		if (user.getConsultations().isEmpty() && user.getAnimaux().isEmpty() && user.getFormulaires().isEmpty()) {
			userService.removeOne(user.getId());
			model.addAttribute("userList", userList);
			model.addAttribute("removeSuccess", true);
		} else {
			List<Consultation> consultList = consultService.findAll();
			List<Animal> animalList = animalService.findAll();
			List<Formulaire> formulaireList = formulaireService.findAll();
			if (!consultList.isEmpty()) {
				for (Consultation elem : consultList) {
					if (elem.getPersonne().getId() == user.getId()) {
						consultService.removeOne(elem.getId());
					}
				}
			}
			if (!animalList.isEmpty()) {
				for (Animal elem : animalList) {
					if (elem.getPersonne().getId() == user.getId()) {
						animalService.removeOne(elem.getId());
					}
				}
			}
			if (!formulaireList.isEmpty()) {
				for (Formulaire elem : formulaireList) {
					if (elem.getPersonne().getId() == user.getId()) {
						elem.setPersonne(null);
					}
				}
			}
			userService.removeOne(user.getId());
			model.addAttribute("userList", userList);
			model.addAttribute("removeSuccess", true);
		}
		return "/user/listUsers";

	}

	@GetMapping("/listVeto")
	public String getListVeto(Model model) {
		List<Veterinaire> vetoList = veterinaireService.findAll();
		vetoList.remove(0);
		model.addAttribute("vetoList", vetoList);
		return "/user/listVeto";
	}

	@RequestMapping(value = "/removeVeto", method = RequestMethod.POST)
	public String removeVeto(@ModelAttribute("id") String id, Model model) {
		Veterinaire veto = veterinaireService.findOne(Long.parseLong(id.substring(8)));
		List<Veterinaire> vetoList = veterinaireService.findAll();
		if (veto.getConsultations().isEmpty() && veto.getFormulaire().isEmpty()) {
			veterinaireService.removeOne(Long.parseLong(id.substring(8)));
			model.addAttribute("vetoList", vetoList);
			model.addAttribute("removeSuccess", true);
		} else {
			List<Consultation> consultList = consultService.findAll();
			List<Formulaire> formulaireList = formulaireService.findAll();
			if (!consultList.isEmpty()) {
				for (Consultation elem : consultList) {
					if (elem.getPersonne().getId() == veto.getId()) {
						consultService.removeOne(elem.getId());
					}
				}
			}
			if (!formulaireList.isEmpty()) {
				for (Formulaire elem : formulaireList) {
					if (elem.getPersonne().getId() == veto.getId()) {
						elem.setPersonne(null);
					}
				}
			}
			veterinaireService.removeOne(Long.parseLong(id.substring(8)));
			model.addAttribute("vetoList", vetoList);
			model.addAttribute("removeSuccess", true);
		}

		return "/user/listVeto";

	}

	@GetMapping("/listSM")
	public String getListSM(Model model) {
		List<SecretaireMedical> smList = smService.findAll();
		model.addAttribute("smList", smList);
		return "/user/listSM";
	}

	@RequestMapping(value = "/removeSM", method = RequestMethod.POST)
	public String removeSM(@ModelAttribute("id") String id, Model model) {
		SecretaireMedical sm = smService.findOne(Long.parseLong(id.substring(8)));
		List<SecretaireMedical> smList = smService.findAll();
		if (sm.getConsultations().isEmpty()) {
			smService.removeOne(Long.parseLong(id.substring(8)));
			model.addAttribute("smList", smList);
			model.addAttribute("removeSuccess", true);
		} else {
			List<Consultation> consultList = consultService.findAll();
			for (Consultation elem : consultList) {
				if (elem.getPersonne().getId() == sm.getId()) {
					elem.setSecretaireMedical(null);
				}
			}
			smService.removeOne(Long.parseLong(id.substring(8)));
			model.addAttribute("smList", smList);
			model.addAttribute("removeSuccess", true);
		}

		return "/user/listSM";

	}

}
