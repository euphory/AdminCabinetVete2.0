package com.Ledesma.Admin.controllers.consultation;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.services.ConsultationService;

public class ConsultationDay {
	@Autowired
	private ConsultationService consultationService;

	@GetMapping("/home")
    public String getConsultationDay(Model model) {
    	List<Consultation> consult = consultationService.findAll();
    	List<Consultation> consultB = consultationService.findAll();
    	Date date = new Date();
		for(Consultation elem: consult) {
			if(elem.getDate() == date) {
				consultB.add(elem);
			}
		}
    	return "home";
    }
	
	
}
