package com.Ledesma.Admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.Admin.models.Adoptable;

public interface AdoptableRepository extends CrudRepository<Adoptable, Long> {

}
	