package com.Ledesma.Admin.controllers.formulaire;

import java.security.Principal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Ledesma.Admin.models.Adoption;
import com.Ledesma.Admin.models.Formulaire;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.services.AdoptionService;
import com.Ledesma.Admin.services.FormulaireService;
import com.Ledesma.Admin.services.VeterinaireService;
import com.Ledesma.Admin.utility.MailConstructor;

@Controller
@RequestMapping("/formulaire")
public class FormulaireContoller {

	@Autowired
	private FormulaireService formulaireService;
	@Autowired
	private AdoptionService adoptionService;
	@Autowired
	private VeterinaireService veterinaireService;
	@Autowired
	private MailConstructor mailConstructor;
	@Autowired
	private JavaMailSender mailSender;

	@RequestMapping("/formulaireList")
	public String formulaireList(Model model, @RequestParam(value = "refus", required = false) Integer refus,
			@RequestParam(value = "success", required = false) Integer success,
			@RequestParam(value = "alreadyExists", required = false) Integer alreadyExists) {
		List<Formulaire> formulaireList = formulaireService.findAll();
		
		if (refus != null && refus == 1) {
			model.addAttribute("refus", true);
		}
		if (success != null && success == 1) {
			model.addAttribute("success", true);
		}
		model.addAttribute("formulaireList", formulaireList);
		return "/formulaire/formulaireList";

	}

	@RequestMapping("/formulaireInfo")
	public String formulaireInfo(@RequestParam("id") long id, Model model) {
		Formulaire formulaire = formulaireService.findOne(id);

		model.addAttribute("formulaire", formulaire);
		return "/formulaire/formulaireInfo";
	}

	@RequestMapping(value = "/formulaireInfo", method = RequestMethod.POST)
	public String AddFomulaireAdoptionPost(Principal principal, @ModelAttribute("id") String id,
			@ModelAttribute("adoption") Adoption adoption, HttpServletRequest request, Model model) {
		Date date = new Date();
		Adoption a = new Adoption();
		adoption.setId(a.getId());
		List<Formulaire> formulaireList = formulaireService.findAll();
		if (adoption.getDateAdoption() == null) {
			adoption.setDateAdoption(date);
		}
		Veterinaire veterinaire = veterinaireService.findByUsername(principal.getName());
		Formulaire formulaire = formulaireService.findOne(Long.parseLong(id));
		if (formulaire.getVeterinaire() == null) {
			formulaire.setAdoption(adoption);
			formulaire.setVeterinaire(veterinaire);

			adoptionService.save(adoption);

			SimpleMailMessage email = mailConstructor.acceptationFormulaire(request.getLocale(), formulaire);
			mailSender.send(email);
			for (Formulaire elem : formulaireList) {
				if (elem.getAnimal().getId() == formulaire.getAnimal().getId()) {
					if (elem.getAdoption() != formulaire.getAdoption()) {
						formulaireService.removeOne(elem.getId());
					}
				}
			}
			return "redirect:/formulaire/formulaireList?success=1";
		} else {
			return "redirect:/formulaire/formulaireList?alreadyExists=1";
		}
	}

	@RequestMapping(value = "/remove", method = RequestMethod.GET)
	public String remove(@ModelAttribute("id") String id, Model model, HttpServletRequest request) {
		List<Formulaire> formulaireList = formulaireService.findAll();
		model.addAttribute("formulairelList", formulaireList);
		Formulaire formulaire = formulaireService.findOne(Long.parseLong(id));
		SimpleMailMessage email = mailConstructor.refusFormulaire(request.getLocale(), formulaire);
		mailSender.send(email);
		formulaireService.removeOne(Long.parseLong(id));

		return "redirect:/formulaire/formulaireList?refus=1";
	}

}
