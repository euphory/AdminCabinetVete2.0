package com.Ledesma.Admin.services;

import java.util.List;
import java.util.Set;

import com.Ledesma.Admin.models.SecretaireMedical;
import com.Ledesma.Admin.models.security.UserRole;

public interface SecretaireMedicalService {
    
    SecretaireMedical findByUsername(String username);

    SecretaireMedical findByEmail(String email);
    
    SecretaireMedical createUser(SecretaireMedical sm, Set<UserRole> userRoles) throws Exception;
    
    SecretaireMedical save(SecretaireMedical sm);
    
    SecretaireMedical findOne(Long id);
    
	List<SecretaireMedical> findAll();

	void removeOne(Long id);
}
