package com.Ledesma.Admin.repository;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.Admin.models.security.Role;

public interface RoleRepository extends CrudRepository<Role, Long>{
	Role findByname(String name);
}
