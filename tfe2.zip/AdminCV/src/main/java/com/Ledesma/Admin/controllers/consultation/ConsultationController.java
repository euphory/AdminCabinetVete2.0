package com.Ledesma.Admin.controllers.consultation;

import java.security.Principal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.Ledesma.Admin.models.Consultation;
import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.services.ConsultationService;
import com.Ledesma.Admin.services.SecretaireMedicalService;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireService;

@Controller
@RequestMapping("/consultation")
public class ConsultationController {
	@Autowired
	private ConsultationService consultationService;
	@Autowired
	private SecretaireMedicalService smService;
	@Autowired
	private VeterinaireService veterinaireService;
	@Autowired
	private UserService userService;

	@GetMapping("/consultationList")
	public String getConsultation(Model model) {
		List<Consultation> consultationList = consultationService.findAll();
		consultationList.sort(Comparator.comparing(o -> o.getHeureDebut()));
		consultationList.sort(Comparator.comparing(o -> o.getDate()));
		Collections.reverse(consultationList);
		List<User> userList = userService.findAll();
		List<Veterinaire> veterinaireList = veterinaireService.findAll();
		veterinaireList.remove(0);

		model.addAttribute("vetoList", veterinaireList);
		model.addAttribute("userList", userList);
		model.addAttribute("consultationList", consultationList);
		return "/consultation/consultationList";
	}

	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String adConsultation(Model model) {
		Consultation consult = new Consultation();
		model.addAttribute("consult", consult);

		return "/consultation/addNew";
	}

	@RequestMapping(value = "/addNew", method = RequestMethod.POST)
	public String addNew(@ModelAttribute("consultation") Consultation consultation, @RequestParam String date,
			@RequestParam String heureDebutTime, @RequestParam String heureFinTime, Principal principal,
			@RequestParam Long idPersonne, @RequestParam Long idVeterinaire, Model model) {
		Consultation consultationb = new Consultation();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
		List<Consultation> consult = consultationService.findAll();
		try {
			consultation.setHeureDebut(sdf.parse(date.concat(" ").concat(heureDebutTime)));
			consultation.setHeureFin(sdf.parse(date.concat(" ").concat(heureFinTime)));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if (consultation.getHeureDebut().compareTo(consultation.getHeureFin()) > 0) {
			consultationb.setHeureDebut(consultation.getHeureFin());
			consultation.setHeureFin(consultation.getHeureDebut());
			consultation.setHeureDebut(consultationb.getHeureFin());
		}
		for (Consultation con : consult) {
			if (con.getDate() == consultation.getDate() && con.getVeterinaire() == consultation.getVeterinaire()) {
				if (consultation.getHeureDebut().compareTo(con.getHeureDebut()) > 0
						&& consultation.getHeureDebut().compareTo(con.getHeureFin()) < 0) {
					model.addAttribute("consultExist", true);
					System.out.println("je suis La A");

					return "redirect:/consultation/consultationList";
				} else {
					consultation.setPersonne(userService.findOne(idPersonne));
					consultation.setVeterinaire(veterinaireService.findOne(idVeterinaire));
					consultationService.save(consultation);
					model.addAttribute("success", true);
					System.out.println("je suis La B");

					return "redirect:/consultation/consultationList";

				}
			} else {
				consultation.setPersonne(userService.findOne(idPersonne));
				consultation.setVeterinaire(veterinaireService.findOne(idVeterinaire));
				consultationService.save(consultation);
				model.addAttribute("success", true);
				System.out.println("je suis La C");

				return "redirect:/consultation/consultationList";

			}

		}

		return "redirect:/consultation/consultationList";
	}

}
