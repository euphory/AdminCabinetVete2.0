package com.Ledesma.Admin.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.Admin.models.Adoption;
import com.Ledesma.Admin.repository.AdoptionRepository;
import com.Ledesma.Admin.services.AdoptionService;

@Service
public class AdoptionServiceImp implements AdoptionService{

	@Autowired
	private AdoptionRepository adoptionRepository;

	public Adoption save(Adoption adoption) {
		return adoptionRepository.save(adoption);
	}
	public List<Adoption> findAll(){
		return (List<Adoption>) adoptionRepository.findAll();
	}
	public Adoption findOne(Long id) {
		return adoptionRepository.findById(id).orElse(null);
	}
	public void removeOne(Long id) {
		adoptionRepository.deleteById(id);
	}
	
	
}
