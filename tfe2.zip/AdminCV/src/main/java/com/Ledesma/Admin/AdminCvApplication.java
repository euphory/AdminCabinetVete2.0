package com.Ledesma.Admin;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.Ledesma.Admin.models.User;
import com.Ledesma.Admin.models.Veterinaire;
import com.Ledesma.Admin.models.security.Role;
import com.Ledesma.Admin.models.security.UserRole;
import com.Ledesma.Admin.services.UserService;
import com.Ledesma.Admin.services.VeterinaireService;
import com.Ledesma.Admin.utility.SecurityUtility;



@SpringBootApplication
public class AdminCvApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(AdminCvApplication.class, args);
	}
	@Autowired
	private UserService userService;
	@Autowired
	private VeterinaireService veterinaireService;

	@Override	
	public void run(String... args) throws Exception {
		Veterinaire user1 = new Veterinaire();
		user1.setUsername("admin");
		user1.setPassword(SecurityUtility.passwordEncoder().encode("admin"));
		user1.setEmail("admin@gmail.com");
		Set<UserRole> userRoles = new HashSet<>();
		Role role1= new Role();
		role1.setRoleId(0);
		role1.setName("ROLE_ADMIN");

		userRoles.add(new UserRole(user1, role1));
		
		veterinaireService.createUser(user1, userRoles);
		
		
	}
}

