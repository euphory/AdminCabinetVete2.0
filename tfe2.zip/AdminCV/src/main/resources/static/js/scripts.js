/**
 * 
 */

$(document).ready(function() {
	$('.delete-animal').on('click', function (){
		/*<![CDATA[*/
	    var path = /*[[@{/}]]*/'remove';
	    /*]]>*/
		
		var id=$(this).attr('id');
		
		bootbox.confirm({
			message: "Voulez-vous vraiment supprimer cette donnee?",
			buttons: {
				cancel: {
					label:'<i class="fa fa-times"></i> Cancel'
				},
				confirm: {
					label:'<i class="fa fa-check"></i> Confirm'
				}
			},
			callback: function(confirmed) {
				if(confirmed) {
					$.post(path, {'id':id}, function(res) {
						location.reload();
					});
				}
			}
		});
	});
	
	
	
//	$('.checkboxAnimal').click(function () {
//        var id = $(this).attr('id');
//        if(this.checked){
//            animalIdList.push(id);
//        }
//        else {
//            animalIdList.splice(animalIdList.indexOf(id), 1);
//        }
//    })
	
	$('#deleteSelected').click(function() {
		var idList= $('.checkboxAnimal');
		var animalIdList=[];
		for (var i = 0; i < idList.length; i++) {
			if(idList[i].checked==true) {
				animalIdList.push(idList[i]['id'])
			}
		}
		
		console.log(animalIdList);
		
		/*<![CDATA[*/
	    var path = /*[[@{/}]]*/'removeList';
	    /*]]>*/
	    
	    bootbox.confirm({
			message: "Voulez-vous vraiment supprimer ces donnees?",
			buttons: {
				cancel: {
					label:'<i class="fa fa-times"></i> Cancel'
				},
				confirm: {
					label:'<i class="fa fa-check"></i> Confirm'
				}
			},
			callback: function(confirmed) {
				if(confirmed) {
					$.ajax({
						type: 'POST',
						url: path,
						data: JSON.stringify(animalIdList),
						contentType: "application/json",
						success: function(res) {
							console.log(res); 
						 	location.reload()
							},
						error: function(res){
							console.log(res); 
							 location.reload();
							}
					});
				}
			}
		});
	});
	
	$("#selectAllAnimal").click(function() {
		if($(this).prop("checked")==true) {
			$(".checkboxAnimal").prop("checked",true);
		} else if ($(this).prop("checked")==false) {
			$(".checkboxAnimal").prop("checked",false);
		}
	})
});