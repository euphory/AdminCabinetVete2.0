package com.Ledesma;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.Ledesma.models.User;
import com.Ledesma.models.security.Role;
import com.Ledesma.models.security.UserRole;
import com.Ledesma.services.UserService;
import com.Ledesma.utility.SecurityUtility;

@SpringBootApplication
public class CabinetVeterinaireApplication implements CommandLineRunner {
	@Autowired
	private UserService userService;

	public static void main(String[] args) {
		SpringApplication.run(CabinetVeterinaireApplication.class, args);
	}
	public void run(String... args) throws Exception {
		User user1 = new User();
		user1.setFirstName("John");
		user1.setFirstName("Adams");
		user1.setUsername("j");
		user1.setPassword(SecurityUtility.passwordEncoder().encode("p"));
		user1.setEmail("JAdams@gmail.com");
		user1.setAdresse("place maurice van meenen 15 bt00");
		user1.setNumAssurance("04556548");
		user1.setTelephone("0486559173");
		Set<UserRole> userRoles = new HashSet<>();
		Role role1= new Role();
		role1.setRoleId(1);
		role1.setName("ROLE_USER");
		userRoles.add(new UserRole(user1, role1));
		
		userService.createUser(user1, userRoles);
	}
}

