package com.Ledesma.repositories;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.models.Antecedent;

public interface AntecedentRepository extends CrudRepository<Antecedent, Long> {

}
