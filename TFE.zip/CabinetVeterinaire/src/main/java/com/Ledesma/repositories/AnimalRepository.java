/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.repositories;

import org.springframework.data.repository.CrudRepository;

import com.Ledesma.models.Animal;


public interface AnimalRepository extends CrudRepository<Animal, Long> {

}
