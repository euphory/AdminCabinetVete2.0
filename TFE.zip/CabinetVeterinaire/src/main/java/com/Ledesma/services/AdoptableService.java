package com.Ledesma.services;

import java.util.List;

import com.Ledesma.models.Adoptable;

public interface AdoptableService {
	Adoptable save(Adoptable adoptable);
	
	List<Adoptable> findAll();

}
