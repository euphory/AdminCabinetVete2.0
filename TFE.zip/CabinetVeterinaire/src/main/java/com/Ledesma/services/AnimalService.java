package com.Ledesma.services;

import java.util.List;

import com.Ledesma.models.Animal;

public interface AnimalService {
	
	Animal save(Animal animal);
	
	List<Animal> findAll();
	
	 Animal findOne(long id);
	

}
