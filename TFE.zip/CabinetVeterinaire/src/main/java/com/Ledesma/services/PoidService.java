package com.Ledesma.services;

import java.util.List;

import com.Ledesma.models.Poid;

public interface PoidService {
	Poid save(Poid poid);
	
	List<Poid> findAll();
}
