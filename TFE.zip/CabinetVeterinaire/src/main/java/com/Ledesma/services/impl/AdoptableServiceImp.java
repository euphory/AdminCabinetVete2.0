package com.Ledesma.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.models.Adoptable;
import com.Ledesma.repositories.AdoptableRepository;
import com.Ledesma.services.AdoptableService;

@Service
public class AdoptableServiceImp implements AdoptableService{
	@Autowired
	private AdoptableRepository adoptableRepository;

	public Adoptable save(Adoptable adoptable) {
		return adoptableRepository.save(adoptable);
	}
	public List<Adoptable> findAll(){
		return (List<Adoptable>) adoptableRepository.findAll();
	}

}
