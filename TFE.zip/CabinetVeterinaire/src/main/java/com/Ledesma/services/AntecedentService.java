package com.Ledesma.services;

import java.util.List;

import com.Ledesma.models.Antecedent;

public interface AntecedentService {
	
	Antecedent save(Antecedent antecedent);
	
	List<Antecedent> findAll();
	

}
