package com.Ledesma.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Ledesma.models.Animal;
import com.Ledesma.repositories.AnimalRepository;
import com.Ledesma.services.AnimalService;

@Service
public class AnimalServiceImp implements AnimalService{

	@Autowired
	private AnimalRepository animalRepository;

	public Animal save(Animal animal) {
		return animalRepository.save(animal);
	}
	public List<Animal> findAll(){
		return (List<Animal>) animalRepository.findAll();
	}
	public Animal findOne(long id) {
		return animalRepository.findById(id).orElse(null);
	}
	
}
