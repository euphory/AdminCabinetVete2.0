package com.Ledesma.services;

import java.util.List;

import com.Ledesma.models.Espece;


public interface EspeceService {
	Espece save(Espece espece);
	
	List<Espece> findAll();
}
