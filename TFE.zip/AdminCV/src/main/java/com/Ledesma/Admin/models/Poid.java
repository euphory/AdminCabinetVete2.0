/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.Ledesma.Admin.models;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import org.springframework.format.annotation.DateTimeFormat;

/**
 *
 * @author PC
 */
@Entity
public class Poid implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private double masse;
	private Date date;

	/**
	 * -----------------------------------------------------------------------------
	 * -- - Associations --- --
	 * -----------------------------------------------------------------------------
	 */
	@ManyToOne
	@JoinColumn(name = "animal_id")
	private Animal animal;

	
	/**
	 * --
	 * -----------------------------------------------------------------------------
	 * -- - Constructor --- --
	 * -----------------------------------------------------------------------------
	 */
	
	
	public Poid() {}

	public Poid(Long id, double masse, Date date, Animal animal) {
		super();
		this.id = id;
		this.masse = masse;
		this.date = date;
		this.animal = animal;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public double getMasse() {
		return masse;
	}

	public void setMasse(double masse) {
		this.masse = masse;
	}

    @DateTimeFormat(pattern="dd-mm-yyyy")
    public Date getDate() {
        return date;
    }
    @DateTimeFormat(pattern="yyyy-mm-dd")
    public void setDate(Date date) {
        this.date = date;
    }

	public Animal getAnimal() {
		return animal;
	}

	public void setAnimal(Animal animal) {
		this.animal = animal;
	}

	

}
