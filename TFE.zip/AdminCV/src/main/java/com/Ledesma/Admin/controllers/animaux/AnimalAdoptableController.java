package com.Ledesma.Admin.controllers.animaux;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.Ledesma.Admin.models.Adoptable;
import com.Ledesma.Admin.models.Animal;
import com.Ledesma.Admin.models.Espece;
import com.Ledesma.Admin.models.Poid;
import com.Ledesma.Admin.services.AdoptableService;
import com.Ledesma.Admin.services.AnimalService;
import com.Ledesma.Admin.services.EspeceService;
import com.Ledesma.Admin.services.PoidService;

@Controller
@RequestMapping("/animalAdoptable")
public class AnimalAdoptableController {
	
	@Autowired
	private AnimalService animalService;
	@Autowired
	private EspeceService especeService;
	@Autowired
	private AdoptableService adoptableService;
	@Autowired
	private PoidService poidService;
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public String addAnimalAdoptable(Model model) {
		Espece espece= new Espece();
		Animal animal= new Animal();
		Adoptable adoptable = new Adoptable();
		Poid poid = new Poid();

		model.addAttribute("espece", espece);
		model.addAttribute("animal", animal);
		model.addAttribute("adoptable", adoptable);
		model.addAttribute("poid", poid);

		
		return "addAnimalAdoptable";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public String addAnimalAdoptablePost(@ModelAttribute("animal") Animal animal, 
			@ModelAttribute("espece") Espece espece,
			@ModelAttribute("adoptable") Adoptable adoptable,
			@ModelAttribute("poid") Poid poid,			
			HttpServletRequest request){
		Date date= new Date();
		poid.setDate(date);
		animal.setAdoptable(adoptable);
		animal.setEspece(espece);		
	
		poidService.save(poid);
		especeService.save(espece);
		adoptableService.save(adoptable);
		animalService.save(animal);
		
		poid.setAnimal(animal);
		adoptable.setAnimal(animal);
		poidService.save(poid);
		adoptableService.save(adoptable);
		
		MultipartFile animalImage = animal.getAnimalImage();
		
		try {
			byte[]bytes = animalImage.getBytes();
			String name =  animal.getId()+".png";
			BufferedOutputStream stream= new BufferedOutputStream(
					new FileOutputStream(
					new File("src/main/resources/static/image/animaux/animal"+name)));
			stream.write(bytes);
			stream.close();		
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return "redirect:animalAdoptableList";
	}
	
	
	@RequestMapping("animalAdoptableInfo")
	public String animalAdoptableInfo(@RequestParam("id")long id, Model model) {
		Animal animal = animalService.findOne(id);
		model.addAttribute(animal);
		return "animalAdoptableInfo";
	}
	
	@RequestMapping("updateAnimalAdoptable")
	public String updateAnimalAdoptable(@RequestParam("id")long id, Model model) {
		Animal animal  = animalService.findOne(id);
		model.addAttribute("animal", animal);
		return "updateAnimalAdoptable";	
	}
	
	@RequestMapping(value="/updateAnimalAdoptable", method = RequestMethod.POST)
	public String updateAnimalAdoptablePost(@ModelAttribute("animal") Animal animal, HttpServletRequest request) {
		animalService.save(animal);
		
		MultipartFile animalImage = animal.getAnimalImage();
		if (!animalImage.isEmpty()) {
			try {
				byte[]bytes = animalImage.getBytes();
				String name =  animal.getId()+".png";
				BufferedOutputStream stream= new BufferedOutputStream(
						new FileOutputStream(
						new File("src/main/resources/static/image/animaux/animal"+name)));
				stream.write(bytes);
				stream.close();		
			}catch (Exception e) {
				e.printStackTrace();
		}
		}
		return "redirect:/animalAdoptable/animalAdoptableInfo?id="+animal.getId();
	}
	
	@RequestMapping("/animalAdoptableList")
	public String animalAdoptableList(Model model) {
			List<Animal> animalList = animalService.findAll();


			model.addAttribute("animalList", animalList);
			return "animalAdoptableList";
		}
	
}
