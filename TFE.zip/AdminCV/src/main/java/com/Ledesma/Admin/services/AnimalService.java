package com.Ledesma.Admin.services;

import java.util.List;

import com.Ledesma.Admin.models.Animal;

public interface AnimalService {
	
	Animal save(Animal animal);
	
	List<Animal> findAll();
	
	Animal findOne(long id);
}
