package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CabinetVeterinaireApplication {

	public static void main(String[] args) {
		SpringApplication.run(CabinetVeterinaireApplication.class, args);
	}

}
