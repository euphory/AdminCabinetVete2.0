package com.ledesma.CabinetVeterinaire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabinetVeterinaireApplicationTests {

	@Test
	void contextLoads() {
	}

}
